from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field, SecretStr, model_validator

AnswerLetter = Literal["A", "B", "C", "D", "E"]


class QuestionOption(BaseModel):
    letter: AnswerLetter
    text: str = Field(min_length=1, max_length=500)


class GeneratedQuestion(BaseModel):
    vignette: str = Field(min_length=40, max_length=5000)
    options: list[QuestionOption] = Field(min_length=5, max_length=5)
    correct: AnswerLetter
    explanations: dict[AnswerLetter, str]
    educational_objective: str = Field(min_length=10, max_length=1000)
    content_tags: list[str] = Field(min_length=1, max_length=3)

    @model_validator(mode="after")
    def ensure_complete_answer_key(self):
        if [option.letter for option in self.options] != list("ABCDE"):
            raise ValueError("Options must be ordered A through E")
        if set(self.explanations) != set("ABCDE"):
            raise ValueError("Explanations must cover every option")
        if any(not explanation.strip() for explanation in self.explanations.values()):
            raise ValueError("Explanations cannot be blank")
        return self


class GenerateRequest(BaseModel):
    system: str = Field(min_length=1)
    api_key: SecretStr | None = None


class PublicQuestion(BaseModel):
    id: str
    system: str
    vignette: str
    options: list[QuestionOption]


class AnswerRequest(BaseModel):
    chosen: AnswerLetter


class AnswerResult(BaseModel):
    id: str
    chosen: AnswerLetter
    correct: bool
    correct_answer: AnswerLetter
    explanations: dict[AnswerLetter, str]
    educational_objective: str
    content_tags: list[str]


class HistoryItem(BaseModel):
    id: str
    system: str
    chosen: AnswerLetter
    correct_answer: AnswerLetter
    correct: bool
    created_at: datetime
