from app.database import Database
from app.models import GeneratedQuestion

from test_question_models import valid_payload


def test_saved_answer_is_visible_in_history(tmp_path):
    database = Database(tmp_path / "test.db")
    database.initialize()
    question_id = database.save_question("Renal", GeneratedQuestion.model_validate(valid_payload()))

    answer = database.save_answer(question_id, "A")

    assert answer.correct is True
    assert database.history()[0].chosen == "A"
