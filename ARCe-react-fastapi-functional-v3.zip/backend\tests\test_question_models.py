import pytest
from pydantic import ValidationError

from app.models import GeneratedQuestion, QuestionOption


def valid_payload():
    return {
        "vignette": "A 24-year-old man develops gross hematuria one day after an upper respiratory infection.",
        "options": [
            {"letter": "A", "text": "IgA nephropathy"},
            {"letter": "B", "text": "Alport syndrome"},
            {"letter": "C", "text": "Minimal change disease"},
            {"letter": "D", "text": "Membranous nephropathy"},
            {"letter": "E", "text": "Poststreptococcal glomerulonephritis"},
        ],
        "correct": "A",
        "explanations": {letter: f"Explanation {letter}" for letter in "ABCDE"},
        "educational_objective": "Recognize the classic timing of IgA nephropathy.",
        "content_tags": ["Renal"],
    }


def test_generated_question_requires_ordered_five_options():
    question = GeneratedQuestion.model_validate(valid_payload())
    assert [option.letter for option in question.options] == list("ABCDE")


def test_generated_question_rejects_incomplete_explanations():
    payload = valid_payload()
    del payload["explanations"]["E"]
    with pytest.raises(ValidationError):
        GeneratedQuestion.model_validate(payload)


def test_option_requires_non_empty_text():
    with pytest.raises(ValidationError):
        QuestionOption(letter="A", text="")
