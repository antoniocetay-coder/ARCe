from fastapi.testclient import TestClient

from app.main import create_app
from test_question_models import valid_payload


class FakeGenerator:
    def generate(self, system: str, repair_message: str | None = None):
        return valid_payload() | {"content_tags": [system]}


def test_question_answer_history_flow(tmp_path):
    app = create_app(database_path=tmp_path / "test.db", generator=FakeGenerator())
    client = TestClient(app)

    generated = client.post("/api/questions", json={"system": "Renal", "api_key": "not-persisted"})
    assert generated.status_code == 201
    question_id = generated.json()["id"]
    assert "correct" not in generated.json()
    assert "not-persisted" not in generated.text

    result = client.post(f"/api/questions/{question_id}/answer", json={"chosen": "A"})
    assert result.status_code == 200
    assert result.json()["correct"] is True

    history = client.get("/api/history")
    assert history.status_code == 200
    assert history.json()[0]["id"] == question_id


class InvalidThenValidGenerator:
    def __init__(self):
        self.calls = 0
        self.repair_messages: list[str | None] = []

    def generate(self, system: str, repair_message: str | None = None):
        self.calls += 1
        self.repair_messages.append(repair_message)
        if self.calls == 1:
            return {"invalid": True}
        return valid_payload() | {"content_tags": [system]}


def test_generation_repairs_one_invalid_response(tmp_path):
    generator = InvalidThenValidGenerator()
    app = create_app(database_path=tmp_path / "test.db", generator=generator)
    client = TestClient(app)

    response = client.post("/api/questions", json={"system": "Renal"})

    assert response.status_code == 201
    assert generator.calls == 2
    assert generator.repair_messages[1]


class AlwaysInvalidGenerator:
    def generate(self, system: str, repair_message: str | None = None):
        return {"invalid": True}


def test_generation_returns_recoverable_error_after_two_invalid_responses(tmp_path):
    app = create_app(database_path=tmp_path / "test.db", generator=AlwaysInvalidGenerator())
    client = TestClient(app)

    response = client.post("/api/questions", json={"system": "Renal", "api_key": "not-persisted"})

    assert response.status_code == 502
    assert response.json()["detail"] == "Could not generate a valid question. Please try again."
