"use client";

import { FormEvent, useEffect, useState } from "react";

type Letter = "A" | "B" | "C" | "D" | "E";
type Option = { letter: Letter; text: string };
type Question = { id: string; system: string; vignette: string; options: Option[] };
type Result = {
  id: string;
  chosen: Letter;
  correct: boolean;
  correct_answer: Letter;
  explanations: Record<Letter, string>;
  educational_objective: string;
  content_tags: string[];
};
type HistoryItem = {
  id: string;
  system: string;
  chosen: Letter;
  correct_answer: Letter;
  correct: boolean;
  created_at: string;
};

async function api<T>(path: string, options?: RequestInit): Promise<T> {
  const response = await fetch(path, {
    ...options,
    headers: { "Content-Type": "application/json", ...options?.headers },
  });
  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw new Error(body.detail || "Nao foi possivel concluir esta acao.");
  }
  return response.json() as Promise<T>;
}

export default function Home() {
  const [systems, setSystems] = useState<string[]>([]);
  const [system, setSystem] = useState("General_Principles");
  const [question, setQuestion] = useState<Question | null>(null);
  const [chosen, setChosen] = useState<Letter | null>(null);
  const [result, setResult] = useState<Result | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [apiKey, setApiKey] = useState("");
  const [draftKey, setDraftKey] = useState("");
  const [showKey, setShowKey] = useState(false);

  useEffect(() => {
    const savedKey = window.sessionStorage.getItem("arce_gemini_key") || "";
    setApiKey(savedKey);
    setDraftKey(savedKey);
    api<string[]>("/api/systems").then(setSystems).catch((cause: Error) => setError(cause.message));
    refreshHistory();
  }, []);

  async function refreshHistory() {
    try {
      setHistory(await api<HistoryItem[]>("/api/history"));
    } catch {
      // The practice flow remains usable if history is temporarily unavailable.
    }
  }

  function saveKey(event: FormEvent) {
    event.preventDefault();
    const value = draftKey.trim();
    setApiKey(value);
    if (value) window.sessionStorage.setItem("arce_gemini_key", value);
    else window.sessionStorage.removeItem("arce_gemini_key");
    setDrawerOpen(false);
  }

  async function generate() {
    if (!apiKey) {
      setDrawerOpen(true);
      return;
    }
    setLoading(true);
    setError("");
    setQuestion(null);
    setResult(null);
    setChosen(null);
    try {
      setQuestion(
        await api<Question>("/api/questions", {
          method: "POST",
          body: JSON.stringify({ system, api_key: apiKey }),
        }),
      );
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Erro ao gerar questao.");
    } finally {
      setLoading(false);
    }
  }

  async function submit() {
    if (!question || !chosen) return;
    setLoading(true);
    setError("");
    try {
      setResult(
        await api<Result>(`/api/questions/${question.id}/answer`, {
          method: "POST",
          body: JSON.stringify({ chosen }),
        }),
      );
      refreshHistory();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Erro ao registrar resposta.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="shell">
      <header className="header">
        <a className="brand" href="/">ARCe<span>USMLE STEP 1</span></a>
        <button className={apiKey ? "api-button configured" : "api-button"} onClick={() => setDrawerOpen(true)}>
          <span className="key-dot" /> {apiKey ? "Gemini configurada" : "Adicionar API key"}
        </button>
      </header>

      <section className="hero">
        <p className="eyebrow">PR&Aacute;TICA FOCADA</p>
        <h1>Uma boa quest&atilde;o.<br />Um passo real.</h1>
        <p className="subtitle">Escolha um sistema, responda uma vinheta Step 1 e revise cada alternativa.</p>
      </section>

      {!question && (
        <section className="generator panel">
          <div className="field">
            <label htmlFor="system">Sistema</label>
            <select id="system" value={system} onChange={(event) => setSystem(event.target.value)} disabled={loading}>
              {systems.length
                ? systems.map((item) => <option key={item} value={item}>{item.replaceAll("_", " ")}</option>)
                : <option>{system}</option>}
            </select>
          </div>
          {!apiKey && <button className="key-callout" onClick={() => setDrawerOpen(true)}>Adicione sua chave Gemini para gerar quest&otilde;es &rarr;</button>}
          <button className="primary" onClick={generate} disabled={loading}>
            {loading ? "Gerando e validando..." : "Gerar questao"}
          </button>
          <small>A chave fica apenas nesta aba do navegador e n&atilde;o &eacute; salva no banco.</small>
        </section>
      )}

      {question && (
        <section className="question panel">
          <div className="question-meta"><span>{question.system.replaceAll("_", " ")}</span><span>USMLE Step 1</span></div>
          <p className="vignette">{question.vignette}</p>
          <div className="options">
            {question.options.map((option) => {
              const answerState = result
                ? option.letter === result.correct_answer
                  ? "correct"
                  : option.letter === result.chosen
                    ? "incorrect"
                    : ""
                : chosen === option.letter
                  ? "selected"
                  : "";
              return (
                <button
                  key={option.letter}
                  className={`option ${answerState}`}
                  disabled={Boolean(result) || loading}
                  onClick={() => setChosen(option.letter)}
                >
                  <b>{option.letter}</b><span>{option.text}</span>
                </button>
              );
            })}
          </div>
          {!result && <button className="primary" onClick={submit} disabled={!chosen || loading}>{loading ? "Registrando..." : "Enviar resposta"}</button>}
        </section>
      )}

      {result && (
        <section className="result panel">
          <p className={result.correct ? "outcome success" : "outcome failure"}>
            {result.correct ? "Correto" : `Incorreto - resposta: ${result.correct_answer}`}
          </p>
          <h2>Revis&atilde;o das alternativas</h2>
          {question?.options.map((option) => (
            <article key={option.letter} className={option.letter === result.correct_answer ? "explanation right" : "explanation"}>
              <b>{option.letter}. {option.text}</b>
              <p>{result.explanations[option.letter]}</p>
            </article>
          ))}
          <div className="objective">
            <strong>Educational objective</strong>
            <p>{result.educational_objective}</p>
            <small>{result.content_tags.join(" / ")}</small>
          </div>
          <button className="primary" onClick={generate} disabled={loading}>{loading ? "Gerando..." : "Gerar outra questao"}</button>
        </section>
      )}

      {error && <div className="error" role="alert">{error}<button onClick={() => setError("")} aria-label="Fechar">&times;</button></div>}

      <section className="history">
        <div className="section-title"><h2>Hist&oacute;rico</h2><span>{history.length} respondida{history.length === 1 ? "" : "s"}</span></div>
        {history.length === 0
          ? <p className="empty">As quest&otilde;es respondidas aparecer&atilde;o aqui.</p>
          : <div className="history-list">{history.map((item) => (
              <div key={item.id} className="history-row">
                <span className={item.correct ? "badge ok" : "badge no"}>{item.correct ? "Acertou" : "Errou"}</span>
                <b>{item.system.replaceAll("_", " ")}</b>
                <span>{item.chosen} / {item.correct_answer}</span>
                <time>{new Date(item.created_at).toLocaleDateString("pt-BR")}</time>
              </div>
            ))}</div>}
      </section>

      {drawerOpen && (
        <div className="drawer-layer" role="presentation" onMouseDown={(event) => event.target === event.currentTarget && setDrawerOpen(false)}>
          <aside className="drawer" aria-label="Configurar Google Gemini">
            <div className="drawer-head"><div><p className="eyebrow">CONFIGURACAO</p><h2>Google Gemini</h2></div><button onClick={() => setDrawerOpen(false)} aria-label="Fechar">&times;</button></div>
            <p className="drawer-copy">Cole sua API key do Google AI Studio. Ela fica somente nesta aba e &eacute; enviada ao backend apenas ao gerar uma quest&atilde;o.</p>
            <form onSubmit={saveKey}>
              <label htmlFor="api-key">API key</label>
              <div className="key-input">
                <input id="api-key" type={showKey ? "text" : "password"} value={draftKey} onChange={(event) => setDraftKey(event.target.value)} placeholder="AIza..." autoComplete="off" />
                <button type="button" onClick={() => setShowKey((value) => !value)}>{showKey ? "Ocultar" : "Mostrar"}</button>
              </div>
              <button className="primary" type="submit">Salvar nesta aba</button>
            </form>
            {apiKey && <button className="remove-key" onClick={() => { setDraftKey(""); setApiKey(""); window.sessionStorage.removeItem("arce_gemini_key"); }}>Remover chave</button>}
          </aside>
        </div>
      )}
    </main>
  );
}
