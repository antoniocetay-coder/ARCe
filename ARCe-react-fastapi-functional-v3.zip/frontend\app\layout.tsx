import "./globals.css";

export const metadata = {
  title: "ARCe · USMLE Step 1",
  description: "Prática focada para o USMLE Step 1",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="pt-BR"><body>{children}</body></html>;
}
