# ARCe — USMLE Step 1

## Codespaces

1. Rebuild the container once so `.devcontainer/devcontainer.json` installs Node 22.
2. Run `npm install`, `npm --prefix frontend install`, and `python -m pip install -r backend/requirements.txt`.
3. Run `npm run dev` and open the forwarded port 3000.
4. Click **Adicionar API key** in the app and paste the Google AI Studio key.

The key remains in `sessionStorage` for the current browser tab, is sent only when generating a question, and is never persisted in SQLite.
