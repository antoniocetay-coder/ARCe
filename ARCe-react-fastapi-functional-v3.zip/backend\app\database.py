import json
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path

from .models import AnswerResult, GeneratedQuestion, HistoryItem, PublicQuestion


class Database:
    def __init__(self, path: Path):
        self.path = path

    def _connection(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        return connection

    def initialize(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._connection() as connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS questions (
                    id TEXT PRIMARY KEY,
                    system TEXT NOT NULL,
                    question_json TEXT NOT NULL,
                    chosen TEXT,
                    created_at TEXT NOT NULL,
                    answered_at TEXT
                )
                """
            )

    def save_question(self, system: str, question: GeneratedQuestion) -> str:
        question_id = str(uuid.uuid4())
        created_at = datetime.now(timezone.utc).isoformat()
        with self._connection() as connection:
            connection.execute(
                "INSERT INTO questions (id, system, question_json, created_at) VALUES (?, ?, ?, ?)",
                (question_id, system, question.model_dump_json(), created_at),
            )
        return question_id

    def public_question(self, question_id: str) -> PublicQuestion | None:
        row = self._get(question_id)
        if row is None:
            return None
        question = GeneratedQuestion.model_validate_json(row["question_json"])
        return PublicQuestion(id=row["id"], system=row["system"], vignette=question.vignette, options=question.options)

    def save_answer(self, question_id: str, chosen: str) -> AnswerResult:
        row = self._get(question_id)
        if row is None:
            raise KeyError(question_id)
        question = GeneratedQuestion.model_validate_json(row["question_json"])
        with self._connection() as connection:
            connection.execute(
                "UPDATE questions SET chosen = ?, answered_at = ? WHERE id = ?",
                (chosen, datetime.now(timezone.utc).isoformat(), question_id),
            )
        return AnswerResult(
            id=question_id,
            chosen=chosen,
            correct=chosen == question.correct,
            correct_answer=question.correct,
            explanations=question.explanations,
            educational_objective=question.educational_objective,
            content_tags=question.content_tags,
        )

    def history(self) -> list[HistoryItem]:
        with self._connection() as connection:
            rows = connection.execute(
                "SELECT * FROM questions WHERE chosen IS NOT NULL ORDER BY answered_at DESC"
            ).fetchall()
        items: list[HistoryItem] = []
        for row in rows:
            question = json.loads(row["question_json"])
            items.append(
                HistoryItem(
                    id=row["id"],
                    system=row["system"],
                    chosen=row["chosen"],
                    correct_answer=question["correct"],
                    correct=row["chosen"] == question["correct"],
                    created_at=row["created_at"],
                )
            )
        return items

    def _get(self, question_id: str) -> sqlite3.Row | None:
        with self._connection() as connection:
            return connection.execute("SELECT * FROM questions WHERE id = ?", (question_id,)).fetchone()
