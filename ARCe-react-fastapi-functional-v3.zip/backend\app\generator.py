import os
from typing import Protocol

from google import genai
from google.genai import types
from pydantic import ValidationError

from .models import GeneratedQuestion


class QuestionGenerator(Protocol):
    def generate(self, system: str, repair_message: str | None = None) -> dict: ...


class GenerationError(Exception):
    pass


class GeminiGenerator:
    def __init__(self, api_key: str | None = None, model: str | None = None):
        self.api_key = api_key or os.getenv("GEMINI_API_KEY")
        self.model = model or os.getenv("GEMINI_MODEL", "gemini-3.5-flash")

    def generate(self, system: str, repair_message: str | None = None) -> dict:
        if not self.api_key:
            raise GenerationError("GEMINI_API_KEY is not configured in the backend environment.")
        client = genai.Client(api_key=self.api_key)
        try:
            response = client.models.generate_content(
                model=self.model,
                contents=self._prompt(system, repair_message),
                config=types.GenerateContentConfig(
                    temperature=0.35,
                    response_mime_type="application/json",
                    response_schema=GeneratedQuestion,
                ),
            )
        except Exception as error:
            raise GenerationError(
                "Google Gemini rejected the request. Check the API key, quota, and configured model."
            ) from error
        if getattr(response, "parsed", None):
            parsed = response.parsed
            if isinstance(parsed, GeneratedQuestion):
                return parsed.model_dump()
            return GeneratedQuestion.model_validate(parsed).model_dump()
        if not response.text:
            raise GenerationError("Gemini returned an empty response.")
        try:
            return GeneratedQuestion.model_validate_json(response.text).model_dump()
        except ValidationError as error:
            raise GenerationError(f"Gemini produced an invalid question: {error}") from error

    @staticmethod
    def _prompt(system: str, repair_message: str | None = None) -> str:
        return f"""
You are an expert NBME-style USMLE Step 1 question writer.
Create exactly one original clinical vignette for the system: {system}.

Write the vignette, five answer options, explanations, and educational objective in English.
Test a high-yield Step 1 concept. Make distractors plausible but unambiguous.
Return only JSON matching the provided schema. Use the selected system as one content tag.
""".strip() + (f"\n\nYour previous output was rejected for this reason: {repair_message}. Correct that exact issue." if repair_message else "")


class QuestionService:
    def __init__(self, generator: QuestionGenerator):
        self.generator = generator

    def generate(self, system: str) -> GeneratedQuestion:
        repair_message: str | None = None
        for _ in range(2):
            try:
                candidate = self.generator.generate(system, repair_message)
                question = GeneratedQuestion.model_validate(candidate)
                if system not in question.content_tags:
                    question = question.model_copy(update={"content_tags": [system, *question.content_tags[:2]]})
                return question
            except (GenerationError, ValidationError, ValueError) as error:
                repair_message = str(error)
        raise GenerationError("Could not generate a valid question. Please try again.")
