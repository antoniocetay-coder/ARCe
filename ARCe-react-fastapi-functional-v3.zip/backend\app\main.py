import os
from pathlib import Path

from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware

from .database import Database
from .generator import GenerationError, GeminiGenerator, QuestionGenerator, QuestionService
from .models import AnswerRequest, AnswerResult, GenerateRequest, HistoryItem, PublicQuestion
from .taxonomy import SYSTEMS


def create_app(database_path: Path | None = None, generator: QuestionGenerator | None = None) -> FastAPI:
    app = FastAPI(title="ARCe USMLE Step 1", version="1.0.0")
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://localhost:3000"],
        allow_methods=["*"],
        allow_headers=["*"],
    )
    database = Database(database_path or Path(os.getenv("DATABASE_PATH", "data/arce.db")))
    database.initialize()
    def get_database() -> Database:
        return database

    @app.get("/api/systems", response_model=list[str])
    def list_systems() -> list[str]:
        return SYSTEMS

    @app.post("/api/questions", response_model=PublicQuestion, status_code=status.HTTP_201_CREATED)
    def create_question(request: GenerateRequest, db: Database = Depends(get_database)) -> PublicQuestion:
        if request.system not in SYSTEMS:
            raise HTTPException(status_code=422, detail="Unknown USMLE system.")
        try:
            selected_generator = generator or GeminiGenerator(
                api_key=request.api_key.get_secret_value() if request.api_key else None
            )
            service = QuestionService(selected_generator)
            question = service.generate(request.system)
        except GenerationError as error:
            raise HTTPException(status_code=502, detail=str(error)) from error
        question_id = db.save_question(request.system, question)
        return db.public_question(question_id)  # type: ignore[return-value]

    @app.post("/api/questions/{question_id}/answer", response_model=AnswerResult)
    def answer_question(question_id: str, request: AnswerRequest, db: Database = Depends(get_database)) -> AnswerResult:
        try:
            return db.save_answer(question_id, request.chosen)
        except KeyError as error:
            raise HTTPException(status_code=404, detail="Question not found.") from error

    @app.get("/api/history", response_model=list[HistoryItem])
    def get_history(db: Database = Depends(get_database)) -> list[HistoryItem]:
        return db.history()

    @app.get("/api/status")
    def get_status() -> dict[str, str | bool]:
        return {
            "status": "ok",
            "provider": "google-gemini",
            "model": os.getenv("GEMINI_MODEL", "gemini-3.5-flash"),
            "gemini_configured": bool(os.getenv("GEMINI_API_KEY")),
        }

    return app


app = create_app()
